#include<stdio.h>
#include<stdlib.h>

int main(void)

{
	float real, cotacao, euro;

	cotacao = 4.00;

	printf("Digite o seu valor em reais:   ");
	scanf_s("%f", &real);

	euro = real / cotacao;
	printf("Voce tem em euros: %.2f \n ",euro);
		

	system("pause");
	return 0;

}
