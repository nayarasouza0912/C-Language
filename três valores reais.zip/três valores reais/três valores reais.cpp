#include<stdio.h>
#include<stdlib.h>

int main(void)

{
	int x, y, z, soma;

	printf("x:");
	scanf_s("%d", &x);

	printf("y:");
	scanf_s("%d", &y);

	printf("z:");
	scanf_s("%d", &z);

	soma = x + y + z;
	
	if (soma >= 50) {
		printf("valor maior ou igual a 50\n");
	}
	else{
			printf("valor fora dos parametros\n");
		}

	system("pause");
	return 0;
}
