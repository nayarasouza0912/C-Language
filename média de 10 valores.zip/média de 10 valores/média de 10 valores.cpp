#include<stdio.h>
#include<stdlib.h>

int main(void)

{
	int num, contador = 0;
	int media;

	for (int i = 1; i <= 10; i++) {
	printf("digite 10 valores:     \n"); 
	printf("numero %d :", i);
	scanf_s("%d", &num);
	contador = contador + num;
	
	}
	media = contador / 10;
	printf("media igual %d\n", media);


	system("pause");
	return (0);
}

